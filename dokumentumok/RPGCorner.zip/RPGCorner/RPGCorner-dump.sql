--
-- PostgreSQL database dump
--

-- Dumped from database version 17.0 (Debian 17.0-1.pgdg120+1)
-- Dumped by pg_dump version 17.0 (Debian 17.0-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: category; Type: TABLE; Schema: public; Owner: RPGCorner
--

CREATE TABLE public.category (
    id bigint NOT NULL,
    active boolean,
    category_type character varying(255),
    description character varying(255),
    main_category_id bigint
);


ALTER TABLE public.category OWNER TO "RPGCorner";

--
-- Name: TABLE category; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON TABLE public.category IS 'A Category entitás.\n<p>\nAz árucikkek kategóriáját kezelő entitása.\n\n@author Kárpáti Gábor';


--
-- Name: COLUMN category.active; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.category.active IS 'Az elem aktív státuszát jelzi.';


--
-- Name: COLUMN category.category_type; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.category.category_type IS 'A kategória típusa.';


--
-- Name: COLUMN category.description; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.category.description IS 'A kategória leírása.';


--
-- Name: contact; Type: TABLE; Schema: public; Owner: RPGCorner
--

CREATE TABLE public.contact (
    id bigint NOT NULL,
    contact_name character varying(255),
    address character varying(255),
    email character varying(255),
    fax character varying(255),
    mobile character varying(255),
    phone character varying(255),
    note character varying(255),
    supplier_id bigint,
    companyname integer,
    taxnumber integer
);


ALTER TABLE public.contact OWNER TO "RPGCorner";

--
-- Name: TABLE contact; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON TABLE public.contact IS 'A Contact entitás.\n<p>\nA kapcsolattartási információk entitása.\n\n@author Kárpáti Gábor';


--
-- Name: COLUMN contact.contact_name; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.contact.contact_name IS 'A kapcsolat neve.';


--
-- Name: COLUMN contact.address; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.contact.address IS 'Cím.';


--
-- Name: COLUMN contact.email; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.contact.email IS 'E-mail cím.';


--
-- Name: COLUMN contact.fax; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.contact.fax IS 'Fax szám.';


--
-- Name: COLUMN contact.mobile; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.contact.mobile IS 'Mobil szám.';


--
-- Name: COLUMN contact.phone; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.contact.phone IS 'Vezetékes telefonszám.';


--
-- Name: COLUMN contact.note; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.contact.note IS 'Megjegyzés';


--
-- Name: customer; Type: TABLE; Schema: public; Owner: RPGCorner
--

CREATE TABLE public.customer (
    id bigint NOT NULL,
    contact_id bigint NOT NULL
);


ALTER TABLE public.customer OWNER TO "RPGCorner";

--
-- Name: TABLE customer; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON TABLE public.customer IS 'A Customer entitás.\n<p>\nA vevő adatait kezelő entitás.\n\n@author Kárpáti Gábor';


--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: RPGCorner
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO "RPGCorner";

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: RPGCorner
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO "RPGCorner";

--
-- Name: dispose; Type: TABLE; Schema: public; Owner: RPGCorner
--

CREATE TABLE public.dispose (
    id bigint NOT NULL,
    dispose_date date,
    note character varying(255),
    disposed_by_user_id bigint NOT NULL,
    transaction_closed boolean DEFAULT false NOT NULL
);


ALTER TABLE public.dispose OWNER TO "RPGCorner";

--
-- Name: TABLE dispose; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON TABLE public.dispose IS 'A Dispose entitás.\n<p>\nA selejtezés entitás.\n\n@author Kárpáti Gábor';


--
-- Name: COLUMN dispose.dispose_date; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.dispose.dispose_date IS 'A selejtezés dátuma.';


--
-- Name: COLUMN dispose.note; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.dispose.note IS 'Megjegyzés.';


--
-- Name: disposed_stock; Type: TABLE; Schema: public; Owner: RPGCorner
--

CREATE TABLE public.disposed_stock (
    id bigint NOT NULL,
    supplie integer,
    unit_price integer,
    disposed_ware_id bigint,
    dispose_id bigint
);


ALTER TABLE public.disposed_stock OWNER TO "RPGCorner";

--
-- Name: TABLE disposed_stock; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON TABLE public.disposed_stock IS 'A DisposedStock entitás.\n<p>\nA selejtezett áru adatait kezelő entitás.\n\n@author Kárpáti Gábor';


--
-- Name: COLUMN disposed_stock.supplie; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.disposed_stock.supplie IS 'A selejtezett áru mennyisége.';


--
-- Name: COLUMN disposed_stock.unit_price; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.disposed_stock.unit_price IS 'Selejtezési egységár.\nEltérhet a beszerzési egységártól.';


--
-- Name: inventory; Type: TABLE; Schema: public; Owner: RPGCorner
--

CREATE TABLE public.inventory (
    id bigint NOT NULL,
    supplie integer,
    ware_id bigint NOT NULL
);


ALTER TABLE public.inventory OWNER TO "RPGCorner";

--
-- Name: TABLE inventory; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON TABLE public.inventory IS 'Az Inventory entitás.\n<p>\nA raktárkészletet nyilvántartó entitás.\n\n@author Kárpáti Gábor';


--
-- Name: COLUMN inventory.supplie; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.inventory.supplie IS 'A raktáron lévő áru mennyisége.';


--
-- Name: jhi_authority; Type: TABLE; Schema: public; Owner: RPGCorner
--

CREATE TABLE public.jhi_authority (
    name character varying(50) NOT NULL
);


ALTER TABLE public.jhi_authority OWNER TO "RPGCorner";

--
-- Name: jhi_user; Type: TABLE; Schema: public; Owner: RPGCorner
--

CREATE TABLE public.jhi_user (
    id bigint NOT NULL,
    login character varying(50) NOT NULL,
    password_hash character varying(60) NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    email character varying(191),
    image_url character varying(256),
    activated boolean NOT NULL,
    lang_key character varying(10),
    activation_key character varying(20),
    reset_key character varying(20),
    created_by character varying(50) NOT NULL,
    created_date timestamp without time zone,
    reset_date timestamp without time zone,
    last_modified_by character varying(50),
    last_modified_date timestamp without time zone
);


ALTER TABLE public.jhi_user OWNER TO "RPGCorner";

--
-- Name: jhi_user_authority; Type: TABLE; Schema: public; Owner: RPGCorner
--

CREATE TABLE public.jhi_user_authority (
    user_id bigint NOT NULL,
    authority_name character varying(50) NOT NULL
);


ALTER TABLE public.jhi_user_authority OWNER TO "RPGCorner";

--
-- Name: product_return; Type: TABLE; Schema: public; Owner: RPGCorner
--

CREATE TABLE public.product_return (
    id bigint NOT NULL,
    return_date date,
    note character varying(255),
    sale_id bigint,
    returned_by_user_id bigint,
    returned_by_customer_id bigint,
    transaction_closed boolean DEFAULT false NOT NULL
);


ALTER TABLE public.product_return OWNER TO "RPGCorner";

--
-- Name: TABLE product_return; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON TABLE public.product_return IS 'A ProductReturn entitás.\n<p>\nAz áruvisszavételeket kezelő entitás.\n\n@author Kárpáti Gábor';


--
-- Name: COLUMN product_return.return_date; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.product_return.return_date IS 'A visszavétel dátuma';


--
-- Name: COLUMN product_return.note; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.product_return.note IS 'Megjegyzés.';


--
-- Name: purchase; Type: TABLE; Schema: public; Owner: RPGCorner
--

CREATE TABLE public.purchase (
    id bigint NOT NULL,
    purchase_date date,
    purchased_by_user_id bigint NOT NULL,
    purchased_from_supplier_id bigint NOT NULL,
    transaction_closed boolean DEFAULT false NOT NULL
);


ALTER TABLE public.purchase OWNER TO "RPGCorner";

--
-- Name: TABLE purchase; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON TABLE public.purchase IS 'A Purchase entitás.\n<p>\nA beszerzés entitás.\n\n@author Kárpáti Gábor';


--
-- Name: COLUMN purchase.purchase_date; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.purchase.purchase_date IS 'A beszerzés időpontja.';


--
-- Name: purchased_stock; Type: TABLE; Schema: public; Owner: RPGCorner
--

CREATE TABLE public.purchased_stock (
    id bigint NOT NULL,
    supplie integer,
    unit_price integer,
    purchased_ware_id bigint,
    purchase_id bigint
);


ALTER TABLE public.purchased_stock OWNER TO "RPGCorner";

--
-- Name: TABLE purchased_stock; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON TABLE public.purchased_stock IS 'A PurchasedStock entitás.\n<p>\nA beszerzett áru adatait kezelő entitás.\n\n@author Kárpáti Gábor';


--
-- Name: COLUMN purchased_stock.supplie; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.purchased_stock.supplie IS 'A beszerzett áru mennyisége.';


--
-- Name: COLUMN purchased_stock.unit_price; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.purchased_stock.unit_price IS 'Beszerzési egység ár';


--
-- Name: returned_stock; Type: TABLE; Schema: public; Owner: RPGCorner
--

CREATE TABLE public.returned_stock (
    id bigint NOT NULL,
    supplie integer,
    unit_price integer,
    returned_ware_id bigint,
    product_return_id bigint
);


ALTER TABLE public.returned_stock OWNER TO "RPGCorner";

--
-- Name: TABLE returned_stock; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON TABLE public.returned_stock IS 'A ReturnedStock entitás.\n<p>\nA visszavett árucikk adatait kezelő entitás.\n\n@author Kárpáti Gábor';


--
-- Name: COLUMN returned_stock.supplie; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.returned_stock.supplie IS 'A visszahozott áru mennyisége.';


--
-- Name: COLUMN returned_stock.unit_price; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.returned_stock.unit_price IS 'A visszavételi egységár.\nEltérhet az eladási egységártól.';


--
-- Name: sale; Type: TABLE; Schema: public; Owner: RPGCorner
--

CREATE TABLE public.sale (
    id bigint NOT NULL,
    sold_date date,
    sold_by_user_id bigint NOT NULL,
    sold_for_customer_id bigint NOT NULL,
    transaction_closed boolean DEFAULT false NOT NULL
);


ALTER TABLE public.sale OWNER TO "RPGCorner";

--
-- Name: TABLE sale; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON TABLE public.sale IS 'A Sale entitás.\n<p>\nAz eladás entitás.\n\n@author Kárpáti Gábor';


--
-- Name: COLUMN sale.sold_date; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.sale.sold_date IS 'Az eladás időpontja.';


--
-- Name: sequence_generator; Type: SEQUENCE; Schema: public; Owner: RPGCorner
--

CREATE SEQUENCE public.sequence_generator
    START WITH 1050
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sequence_generator OWNER TO "RPGCorner";

--
-- Name: sold_stock; Type: TABLE; Schema: public; Owner: RPGCorner
--

CREATE TABLE public.sold_stock (
    id bigint NOT NULL,
    supplie integer,
    unit_price integer,
    returned_supplie integer,
    sold_ware_id bigint,
    sale_id bigint
);


ALTER TABLE public.sold_stock OWNER TO "RPGCorner";

--
-- Name: TABLE sold_stock; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON TABLE public.sold_stock IS 'A SoldStock entitás.\n<p>\nAz eladott áru adatait kezelő entitás.\n\n@author Kárpáti Gábor';


--
-- Name: COLUMN sold_stock.supplie; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.sold_stock.supplie IS 'Az eladott áru mennyisége.';


--
-- Name: COLUMN sold_stock.unit_price; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.sold_stock.unit_price IS 'Eladási egységár.\nEltérhet a beszerzési egységártól.';


--
-- Name: COLUMN sold_stock.returned_supplie; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.sold_stock.returned_supplie IS 'A visszahozott árumennyiség.\nAlapértelmezetten 0. Maximum a supplie értéke.';


--
-- Name: supplier; Type: TABLE; Schema: public; Owner: RPGCorner
--

CREATE TABLE public.supplier (
    id bigint NOT NULL,
    company_name character varying(255),
    tax_number character varying(255)
);


ALTER TABLE public.supplier OWNER TO "RPGCorner";

--
-- Name: TABLE supplier; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON TABLE public.supplier IS 'A Supplier entitás.\n<p>\nA beszállító adatait kezelő entitás.\n\n@author Kárpáti Gábor';


--
-- Name: ware; Type: TABLE; Schema: public; Owner: RPGCorner
--

CREATE TABLE public.ware (
    id bigint NOT NULL,
    active boolean,
    created date,
    name character varying(255),
    description character varying(255),
    product_code character varying(255),
    main_category_id bigint NOT NULL,
    sub_category_id bigint
);


ALTER TABLE public.ware OWNER TO "RPGCorner";

--
-- Name: TABLE ware; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON TABLE public.ware IS 'A Ware entitás.\n<p>\nAz árucikkek entitása.\n\n@author Kárpáti Gábor';


--
-- Name: COLUMN ware.active; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.ware.active IS 'Az elem aktív státuszát jelzi.';


--
-- Name: COLUMN ware.created; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.ware.created IS 'Az árucikk bejegyzésének dátuma.';


--
-- Name: COLUMN ware.name; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.ware.name IS 'Az árucikk megnevezése.';


--
-- Name: COLUMN ware.description; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.ware.description IS 'Az árucikk leírása.';


--
-- Name: COLUMN ware.product_code; Type: COMMENT; Schema: public; Owner: RPGCorner
--

COMMENT ON COLUMN public.ware.product_code IS 'Gyártási azonosító kód';


--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: RPGCorner
--

COPY public.category (id, active, category_type, description, main_category_id) FROM stdin;
1	f	SUB_CATEGORY	Leírás1	2
2	f	MAIN_CATEGORY	Leírás2	\N
3	f	SUB_CATEGORY	Leírás3	\N
4	t	MAIN_CATEGORY	Leírás4	\N
5	f	MAIN_CATEGORY	Leírás5	\N
6	t	SUB_CATEGORY	Leírás6	\N
7	t	SUB_CATEGORY	Leírás7	\N
8	f	SUB_CATEGORY	Leírás8	\N
9	f	SUB_CATEGORY	Leírás9	\N
10	t	SUB_CATEGORY	Leírás10	\N
1201	f	MAIN_CATEGORY	Leírás11	\N
\.


--
-- Data for Name: contact; Type: TABLE DATA; Schema: public; Owner: RPGCorner
--

COPY public.contact (id, contact_name, address, email, fax, mobile, phone, note, supplier_id, companyname, taxnumber) FROM stdin;
7	klarinétos	felelősségteljes tavalyelőtt támogatott	Izabella.Fekete49@gmail.com	abbizony plus	bárcsak áramtalanító összeadás	0036504011210	bizonyítvány	\N	\N	\N
8	valameddig tavalyelőtt	átépit trivializál against	Zejnep54@outlook.com	gondosan egyenesen	fegyverraktár kivéve ha	06503817842	hehe madridi könyörtelenül	\N	\N	\N
4351	Test	Test	Testsqweqweqweqwe1	Test	Test	Test	Test	\N	\N	\N
4401	Test4	Test4	Test4@Test4.Test4	Test4	Test4	Test4	Test4	\N	\N	\N
4402	Test4	Test4	Test4@Test4.Test4	Test4	Test4	Test4	Test4	\N	\N	\N
4403	Test5	Test4	Test4@Test4.Test4	Test4	Test4	Test4	Test4	\N	\N	\N
4404	Test4@Test4.Test4	Test4@Test4.Test4	Test4@Test4.Test4	Test4@Test4.Test4	Test4@Test4.Test4	Test4@Test4.Test4	Test4@Test4.Test4	\N	\N	\N
4501	Test4@Test4.Test4	Test4@Test4.Test4	Test4@Test4.Test4	Test4@Test4.Test4	Test4@Test4.Test4	Test4@Test4.Test4	Test4@Test4.Test4	\N	\N	\N
4502	1	Test4@Test4.Test4	Test4@Test4.Test4	Test4@Test4.Test4	Test4@Test4.Test4	Test4@Test4.Test4	Test4@Test4.Test4	\N	\N	\N
4503	1	Test4@Test4.Test4	Test4@Test4.Test4	Test4@Test4.Test42	Test4@Test4.Test4	Test4@Test4.Test4	Test4@Test4.Test4	\N	\N	\N
4504	1	Test4@Test4.Test4	Test4@Test4.Test43	Test4@Test4.Test42	Test4@Test4.Test4	Test4@Test4.Test4	Test4@Test4.Test4	\N	\N	\N
4505	Test6	Test6	Test6@Test6.Test6	Test6	Test6	Test6	Test6	\N	\N	\N
4506	Test6	Test6	Test6@Test6.Test6	Test6	Test6	Test6	Test6	\N	\N	\N
4507	Test7	Test6	Test6@Test6.Test6	Test6	Test6	Test6	Test6	\N	\N	\N
4508	Test8	Test8	Test8@Test8.Test8	Test8	Test8	Test8	Test8	\N	\N	\N
4509	Test8	Test8	Test8@Test8.Test8	Test8	Test8	Test8	Test8	\N	\N	\N
4510	Test9	Test8	Test8@Test8.Test8	Test8	Test8	Test8	Test8	\N	\N	\N
3302	Jane Doe	456 Elm St	jane.doe@example.com	\N	\N	\N	\N	1	\N	\N
4601	Test10	Test10	Test10@Test10.Test10	Test10	Test10	Test10	Test10	\N	\N	\N
3202	123	123	123	123	123	123	123	\N	\N	\N
10	hol	illetőleg	Kolos.Molnar78@outlook.hu	brr pedikűröz begörcsöl	erőltetés pszichoaktív	+36 70/868-2895	hív átépit	\N	\N	\N
3051	CCC	324	2342	234	23423	2342	234	\N	\N	\N
3301	3	3	3	3	3	3	3	\N	\N	\N
3303	33	3	3	4	4	5	6	\N	\N	\N
9	óh megfertőz alma	csörgedezik nemcsak	Bella_Torok@hotamil.com	dupla brr	bűntudatos	+36 50/005-1180	csorbóka keneget	\N	\N	\N
3201	12	123	123	12312	123	123	123	\N	\N	\N
1003	wer	wer	wer	wer	wer	wer	wer	\N	\N	\N
1002	Test	Test	Test	Test	Test	Test	Test	\N	\N	\N
4	Név4	a görkorcsolya	Izabella_Somogyi67@outlook.hu	off aprított	jaj meg előboltosulás	+36 70/356-7366	á fegyverraktár	\N	\N	\N
1001	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4001	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2	Név2	Cím2	email2@email.hu	+38 30/377-9311	+36 10/377-9311	+36 30/377-9311	megjegyzés2	\N	\N	\N
4101	Test	Test	Test@Test.hu	Test@Test.hu	Test@Test.hu	Test@Test.hu	Test@Test.hu	\N	\N	\N
4102	Test	Test	Test1@Test.hu	Test@Test.hu	Test@Test.hu	Test@Test.hu	Test@Test.hu	\N	\N	\N
4103	Test1	Test	Test1@Test.hu	Test@Test.hu	Test@Test.hu	Test@Test.hu	Test@Test.hu	\N	\N	\N
4201	Test	Test	Test@Test.hu	t	t	t	t	\N	\N	\N
4202	Test	Test	Test@Test.hu1	t	t	t	t	\N	\N	\N
4251	Test	Test	Test	Test	Test	Test	Test	\N	\N	\N
4252	Test	Test	Tests	Test	Test	Test	Test	\N	\N	\N
4253	Test	Test	Testsqweqweqweqwe	Test	Test	Test	Test	\N	\N	\N
4254	Test	Test	Testsqweqweqweqwe	Test	Test	Test	Test	\N	\N	\N
4255	Test	Test	Testsqweqweqweqwe	Test	Test	Test	Test	\N	\N	\N
4256	Test	Test	Testsqweqweqweqwe1	Test	Test	Test	Test	\N	\N	\N
4301	Test	Test	Testsqweqweqweqwe1	Test	Test	Test	Test	\N	\N	\N
4602	Test10	Test10	Test10@Test10.Test10	Test10	Test10	Test10	Test10	\N	\N	\N
4603	Test11	Test10	Test10@Test10.Test10	Test10	Test10	Test10	Test10	\N	\N	\N
4701	Test12	Test12	Test12@Test12.hu	Test12	Test12	Test12	Test12	\N	\N	\N
4702	Test12	Test12	Test12@Test12.hu	Test12	Test12	Test12	Test12	\N	\N	\N
4703	Test13	Test12	Test12@Test12.hu	Test12	Test12	Test12	Test12	\N	\N	\N
4801	Test20	Test20	Test20@Test20.hu	Test20	Test20	Test20	Test20	\N	\N	\N
4802	Test20	Test20	Test21@Test21.hu	Test20	Test20	Test20	Test20	\N	\N	\N
4901	Test30	Test30	Test30@Test30.hu	Test30	Test30	Test30	Test30	\N	\N	\N
4902	Test30	Test30	Test30@Test30.hu	Test30	Test30	Test30	Test30	\N	\N	\N
4903	Test31	Test30	Test30@Test30.hu	Test30	Test30	Test30	Test30	\N	\N	\N
5001	Test40	Test40	Test40@Test40.hu	Test40	Test40	Test40	Test40	\N	\N	\N
5002	Test40	Test40	Test40@Test40.hu	Test40	Test40	Test40	Test40	\N	\N	\N
5003	Test41	Test40	Test40@Test40.hu	Test40	Test40	Test40	Test40	\N	\N	\N
5101	Test50	Test50	Test50@Test50.hu	Test50	Test50	Test50	Test50	\N	\N	\N
5201	Test50	Test50	Test50@Test50.hu	Test50	Test50	Test50	Test50	\N	\N	\N
5202	Test501	Test50	Test50@Test50.hu	Test50	Test50	Test50	Test50	\N	\N	\N
5301	Test60	Test60	Test60	Test60	Test60	Test60	Test60	\N	\N	\N
5302	Test60	Test60	Test60	Test60	Test60	Test60	Test60	\N	\N	\N
5303	Test604	Test60	Test60	Test60	Test60	Test60	Test60	\N	\N	\N
5401	Test70	Test70	Test70	Test70	Test70	Test70	Test70	\N	\N	\N
5402	Test70	Test70	Test70	Test70	Test70	Test70	Test70	\N	\N	\N
3	Név3	Cím3	email3@email.hu	+36 10/977-9311	+36 20/377-9311	+36 33/377-9311	megjegyzés3	\N	\N	\N
5	Név5	a mindazonáltal kohol	Natalia.Orban@freemail.hu	hivatott abház	afore aha legendás	06703168297	megfellebbez	\N	\N	\N
6	Név6	hajókázik kinn dehidrál	Vince.Mate@hotmail.hu	outside illetőleg	minthogy	+36307764982	sans upon kukucskál	\N	\N	\N
5403	Test701	Test70	Test702	Test70	Test70	Test70	Test70	\N	\N	\N
5405	Test100	Test100	Test100@Test100.hu	Test100	Test100	Test100	Test100	\N	\N	\N
5501	Test101	Test101	Test101	Test101	Test101	Test101	Test101	\N	\N	\N
5404	Test101ccccc	Test100	Test102@Test102.hu	Test100	Test100	Test100	Test100	\N	\N	\N
5406	Test101ccc	Test100	Test101@Test101.hu	Test100	Test100	Test100	Test100	\N	\N	\N
5551	Vv	vv	v	v	v	v	v	\N	\N	\N
1	Név1	Cím1	email1@email.hu	+36 30/377-9311	+36 30/317-9311	+36 20/377-9311	megjegyzés1 	\N	\N	\N
\.


--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: RPGCorner
--

COPY public.customer (id, contact_id) FROM stdin;
1	1
2	2
3	3
4	4
5	5
6	6
7	7
8	8
9	9
10	10
1052	1002
1053	1003
3101	3051
3251	3201
3252	3202
3351	3301
3352	3302
3353	3303
4051	4001
4151	4103
4451	4401
4452	4403
4453	4404
4551	4504
4552	4505
4553	4507
4554	4508
4555	4510
4651	4601
4652	4603
4751	4701
4752	4703
4851	4801
4951	4901
4952	4903
5051	5001
5052	5003
5151	5101
5251	5202
5351	5301
5352	5303
5451	5401
5452	5403
5453	5404
5454	5406
5601	5551
\.


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: RPGCorner
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
00000000000000	jhipster	config/liquibase/changelog/00000000000000_initial_schema.xml	2024-12-10 00:34:05.439269	1	EXECUTED	9:b6b4a3e0d2a6d7f1e5139675af65d7b0	createSequence sequenceName=sequence_generator		\N	4.27.0	\N	\N	3787245361
00000000000001	jhipster	config/liquibase/changelog/00000000000000_initial_schema.xml	2024-12-10 00:34:05.576895	2	EXECUTED	9:8a9c08ebafec892ca6176ef45f171e37	createTable tableName=jhi_user; createTable tableName=jhi_authority; createTable tableName=jhi_user_authority; addPrimaryKey tableName=jhi_user_authority; addForeignKeyConstraint baseTableName=jhi_user_authority, constraintName=fk_authority_name, ...		\N	4.27.0	\N	\N	3787245361
20241209232120-1	jhipster	config/liquibase/changelog/20241209232120_added_entity_Category.xml	2024-12-10 00:34:05.600783	3	EXECUTED	9:988186280b00688e03d5c8b448e68150	createTable tableName=category		\N	4.27.0	\N	\N	3787245361
20241209232120-1-data	jhipster	config/liquibase/changelog/20241209232120_added_entity_Category.xml	2024-12-10 00:34:05.653187	4	EXECUTED	9:79a5e00446b34ad6e2d001a85b0e5946	loadData tableName=category		\N	4.27.0	faker	\N	3787245361
20241209232121-1	jhipster	config/liquibase/changelog/20241209232121_added_entity_Contact.xml	2024-12-10 00:34:05.702432	5	EXECUTED	9:a7618828d70cb0ae0d2753fb8101e7bf	createTable tableName=contact		\N	4.27.0	\N	\N	3787245361
20241209232121-1-data	jhipster	config/liquibase/changelog/20241209232121_added_entity_Contact.xml	2024-12-10 00:34:05.754674	6	EXECUTED	9:ff7961bc31e8c72772c5ba752b66a428	loadData tableName=contact		\N	4.27.0	faker	\N	3787245361
20241209232122-1	jhipster	config/liquibase/changelog/20241209232122_added_entity_Customer.xml	2024-12-10 00:34:05.771917	7	EXECUTED	9:f7a5d516661beead8aacdc16a5891196	createTable tableName=customer		\N	4.27.0	\N	\N	3787245361
20241209232122-1-data	jhipster	config/liquibase/changelog/20241209232122_added_entity_Customer.xml	2024-12-10 00:34:05.804458	8	EXECUTED	9:f495693c44b2ee4254f2bdcaf616e496	loadData tableName=customer		\N	4.27.0	faker	\N	3787245361
20241209232123-1	jhipster	config/liquibase/changelog/20241209232123_added_entity_Dispose.xml	2024-12-10 00:34:05.822247	9	EXECUTED	9:d9ffe4527835e357914010558044093d	createTable tableName=dispose		\N	4.27.0	\N	\N	3787245361
20241209232123-1-data	jhipster	config/liquibase/changelog/20241209232123_added_entity_Dispose.xml	2024-12-10 00:34:05.85107	10	EXECUTED	9:05f14a66b49e295220c51d5e98ac3aa0	loadData tableName=dispose		\N	4.27.0	faker	\N	3787245361
20241209232124-1	jhipster	config/liquibase/changelog/20241209232124_added_entity_DisposedStock.xml	2024-12-10 00:34:05.868638	11	EXECUTED	9:08dae593fa8a6eebef63c9a12b223747	createTable tableName=disposed_stock		\N	4.27.0	\N	\N	3787245361
20241209232124-1-data	jhipster	config/liquibase/changelog/20241209232124_added_entity_DisposedStock.xml	2024-12-10 00:34:05.896322	12	EXECUTED	9:f913a20dae1bc1aa1f042ba7fd9b777e	loadData tableName=disposed_stock		\N	4.27.0	faker	\N	3787245361
20241209232125-1	jhipster	config/liquibase/changelog/20241209232125_added_entity_Inventory.xml	2024-12-10 00:34:05.91026	13	EXECUTED	9:e74178f8a6a9e4d709041319fde26722	createTable tableName=inventory		\N	4.27.0	\N	\N	3787245361
20241209232125-1-data	jhipster	config/liquibase/changelog/20241209232125_added_entity_Inventory.xml	2024-12-10 00:34:05.932995	14	EXECUTED	9:b88b41d614d175c1a8ee7ba35553cc38	loadData tableName=inventory		\N	4.27.0	faker	\N	3787245361
20241209232126-1	jhipster	config/liquibase/changelog/20241209232126_added_entity_ProductReturn.xml	2024-12-10 00:34:05.949931	15	EXECUTED	9:f06c5c60a4334bc054a9f4d9394cc819	createTable tableName=product_return		\N	4.27.0	\N	\N	3787245361
20241209232126-1-data	jhipster	config/liquibase/changelog/20241209232126_added_entity_ProductReturn.xml	2024-12-10 00:34:05.974334	16	EXECUTED	9:c855ba0da451932c20d31ed5eb2219b0	loadData tableName=product_return		\N	4.27.0	faker	\N	3787245361
20241209232127-1	jhipster	config/liquibase/changelog/20241209232127_added_entity_Purchase.xml	2024-12-10 00:34:05.989756	17	EXECUTED	9:bcbaf41462424a207648b9becd8a2c4c	createTable tableName=purchase		\N	4.27.0	\N	\N	3787245361
20241209232127-1-data	jhipster	config/liquibase/changelog/20241209232127_added_entity_Purchase.xml	2024-12-10 00:34:06.019776	18	EXECUTED	9:e26b1f88bc355fb12932540d5635435a	loadData tableName=purchase		\N	4.27.0	faker	\N	3787245361
20241209232128-1	jhipster	config/liquibase/changelog/20241209232128_added_entity_PurchasedStock.xml	2024-12-10 00:34:06.037847	19	EXECUTED	9:1ee5096369367ba9f8257f3c819c68d4	createTable tableName=purchased_stock		\N	4.27.0	\N	\N	3787245361
20241209232128-1-data	jhipster	config/liquibase/changelog/20241209232128_added_entity_PurchasedStock.xml	2024-12-10 00:34:06.062953	20	EXECUTED	9:951f1020bce17ee9e67c4a2319d710b3	loadData tableName=purchased_stock		\N	4.27.0	faker	\N	3787245361
20241209232129-1	jhipster	config/liquibase/changelog/20241209232129_added_entity_ReturnedStock.xml	2024-12-10 00:34:06.07793	21	EXECUTED	9:052666c9e5929a29b5b1c5f9c76993eb	createTable tableName=returned_stock		\N	4.27.0	\N	\N	3787245361
20241209232129-1-data	jhipster	config/liquibase/changelog/20241209232129_added_entity_ReturnedStock.xml	2024-12-10 00:34:06.100823	22	EXECUTED	9:6f858658d98abc83a53aac5b0d9de84c	loadData tableName=returned_stock		\N	4.27.0	faker	\N	3787245361
20241209232130-1	jhipster	config/liquibase/changelog/20241209232130_added_entity_Sale.xml	2024-12-10 00:34:06.112278	23	EXECUTED	9:6d88d9e3034208497bfc3edda40cfa9f	createTable tableName=sale		\N	4.27.0	\N	\N	3787245361
20241209232130-1-data	jhipster	config/liquibase/changelog/20241209232130_added_entity_Sale.xml	2024-12-10 00:34:06.136907	24	EXECUTED	9:7a0a3b17aa94c1e6ff694aa842875845	loadData tableName=sale		\N	4.27.0	faker	\N	3787245361
20241209232131-1	jhipster	config/liquibase/changelog/20241209232131_added_entity_SoldStock.xml	2024-12-10 00:34:06.15293	25	EXECUTED	9:f0df5a8e2dbdbe0bfc20277c4bc7b30d	createTable tableName=sold_stock		\N	4.27.0	\N	\N	3787245361
20241209232131-1-data	jhipster	config/liquibase/changelog/20241209232131_added_entity_SoldStock.xml	2024-12-10 00:34:06.17955	26	EXECUTED	9:ac8c9e5994da569323e03b19e45864d9	loadData tableName=sold_stock		\N	4.27.0	faker	\N	3787245361
20241209232132-1	jhipster	config/liquibase/changelog/20241209232132_added_entity_Supplier.xml	2024-12-10 00:34:06.191629	27	EXECUTED	9:7b4d7b493f4e8ac314a00df22668457f	createTable tableName=supplier		\N	4.27.0	\N	\N	3787245361
20241209232132-1-data	jhipster	config/liquibase/changelog/20241209232132_added_entity_Supplier.xml	2024-12-10 00:34:06.215006	28	EXECUTED	9:114f58e59811a38b0e500814e87e8027	loadData tableName=supplier		\N	4.27.0	faker	\N	3787245361
20241209232133-1	jhipster	config/liquibase/changelog/20241209232133_added_entity_Ware.xml	2024-12-10 00:34:06.232435	29	EXECUTED	9:e2efd97cb425784e2135d81ddae22327	createTable tableName=ware		\N	4.27.0	\N	\N	3787245361
20241209232133-1-data	jhipster	config/liquibase/changelog/20241209232133_added_entity_Ware.xml	2024-12-10 00:34:06.258494	30	EXECUTED	9:6c52165d465c4547d36fc6fab948e42d	loadData tableName=ware		\N	4.27.0	faker	\N	3787245361
20241209232120-2	jhipster	config/liquibase/changelog/20241209232120_added_entity_constraints_Category.xml	2024-12-10 00:34:06.268275	31	EXECUTED	9:50fbe53a035a196fcc811c83000489e4	addForeignKeyConstraint baseTableName=category, constraintName=fk_category__main_category_id, referencedTableName=category		\N	4.27.0	\N	\N	3787245361
20241209232121-2	jhipster	config/liquibase/changelog/20241209232121_added_entity_constraints_Contact.xml	2024-12-10 00:34:06.278671	32	EXECUTED	9:a19e1809b8824507a34feb901a6755bb	addForeignKeyConstraint baseTableName=contact, constraintName=fk_contact__supplier_id, referencedTableName=supplier		\N	4.27.0	\N	\N	3787245361
20241209232122-2	jhipster	config/liquibase/changelog/20241209232122_added_entity_constraints_Customer.xml	2024-12-10 00:34:06.290301	33	EXECUTED	9:19c695dbc3525620a3c1b9e189472865	addForeignKeyConstraint baseTableName=customer, constraintName=fk_customer__contact_id, referencedTableName=contact		\N	4.27.0	\N	\N	3787245361
20241209232123-2	jhipster	config/liquibase/changelog/20241209232123_added_entity_constraints_Dispose.xml	2024-12-10 00:34:06.300156	34	EXECUTED	9:7e67064336621b157066c4db18507899	addForeignKeyConstraint baseTableName=dispose, constraintName=fk_dispose__disposed_by_user_id, referencedTableName=jhi_user		\N	4.27.0	\N	\N	3787245361
20241209232124-2	jhipster	config/liquibase/changelog/20241209232124_added_entity_constraints_DisposedStock.xml	2024-12-10 00:34:06.315573	35	EXECUTED	9:6a739b2fabb9e9bbcd11ec44f0397c6d	addForeignKeyConstraint baseTableName=disposed_stock, constraintName=fk_disposed_stock__disposed_ware_id, referencedTableName=ware; addForeignKeyConstraint baseTableName=disposed_stock, constraintName=fk_disposed_stock__dispose_id, referencedTable...		\N	4.27.0	\N	\N	3787245361
20241209232125-2	jhipster	config/liquibase/changelog/20241209232125_added_entity_constraints_Inventory.xml	2024-12-10 00:34:06.328844	36	EXECUTED	9:cb33d249a75aad95852b2b32db40b590	addForeignKeyConstraint baseTableName=inventory, constraintName=fk_inventory__ware_id, referencedTableName=ware		\N	4.27.0	\N	\N	3787245361
20241209232126-2	jhipster	config/liquibase/changelog/20241209232126_added_entity_constraints_ProductReturn.xml	2024-12-10 00:34:06.356493	37	EXECUTED	9:c2c9a8a2f8dadd1335bc1623ce7b1e98	addForeignKeyConstraint baseTableName=product_return, constraintName=fk_product_return__sale_id, referencedTableName=sale; addForeignKeyConstraint baseTableName=product_return, constraintName=fk_product_return__returned_by_user_id, referencedTable...		\N	4.27.0	\N	\N	3787245361
20241209232127-2	jhipster	config/liquibase/changelog/20241209232127_added_entity_constraints_Purchase.xml	2024-12-10 00:34:06.374167	38	EXECUTED	9:4649e7729464be26d1667d4308363b21	addForeignKeyConstraint baseTableName=purchase, constraintName=fk_purchase__purchased_by_user_id, referencedTableName=jhi_user; addForeignKeyConstraint baseTableName=purchase, constraintName=fk_purchase__purchased_from_supplier_id, referencedTable...		\N	4.27.0	\N	\N	3787245361
20241209232128-2	jhipster	config/liquibase/changelog/20241209232128_added_entity_constraints_PurchasedStock.xml	2024-12-10 00:34:06.386259	39	EXECUTED	9:906682ca2305724f5881d77c2c36c8f8	addForeignKeyConstraint baseTableName=purchased_stock, constraintName=fk_purchased_stock__purchased_ware_id, referencedTableName=ware; addForeignKeyConstraint baseTableName=purchased_stock, constraintName=fk_purchased_stock__purchase_id, reference...		\N	4.27.0	\N	\N	3787245361
20241209232129-2	jhipster	config/liquibase/changelog/20241209232129_added_entity_constraints_ReturnedStock.xml	2024-12-10 00:34:06.397131	40	EXECUTED	9:81cbb99d77ac128b279791adc44d83fa	addForeignKeyConstraint baseTableName=returned_stock, constraintName=fk_returned_stock__returned_ware_id, referencedTableName=ware; addForeignKeyConstraint baseTableName=returned_stock, constraintName=fk_returned_stock__product_return_id, referenc...		\N	4.27.0	\N	\N	3787245361
20241209232130-2	jhipster	config/liquibase/changelog/20241209232130_added_entity_constraints_Sale.xml	2024-12-10 00:34:06.407908	41	EXECUTED	9:e9bcdaad8368884d839c8ea8dddcee19	addForeignKeyConstraint baseTableName=sale, constraintName=fk_sale__sold_by_user_id, referencedTableName=jhi_user; addForeignKeyConstraint baseTableName=sale, constraintName=fk_sale__sold_for_customer_id, referencedTableName=customer		\N	4.27.0	\N	\N	3787245361
20241209232131-2	jhipster	config/liquibase/changelog/20241209232131_added_entity_constraints_SoldStock.xml	2024-12-10 00:34:06.417565	42	EXECUTED	9:b5ce1b0a73da70fd520d91581844c4d6	addForeignKeyConstraint baseTableName=sold_stock, constraintName=fk_sold_stock__sold_ware_id, referencedTableName=ware; addForeignKeyConstraint baseTableName=sold_stock, constraintName=fk_sold_stock__sale_id, referencedTableName=sale		\N	4.27.0	\N	\N	3787245361
20241209232133-2	jhipster	config/liquibase/changelog/20241209232133_added_entity_constraints_Ware.xml	2024-12-10 00:34:06.426907	43	EXECUTED	9:a7f6b40be90d64e809cd0c7d7e7bb4c0	addForeignKeyConstraint baseTableName=ware, constraintName=fk_ware__main_category_id, referencedTableName=category; addForeignKeyConstraint baseTableName=ware, constraintName=fk_ware__sub_category_id, referencedTableName=category		\N	4.27.0	\N	\N	3787245361
add-company-name-to-supplier	jhipster	config/liquibase/changelog/20241209232132_company_name_to_supplier.xml	2024-12-18 16:32:24.846788	44	EXECUTED	9:92812ee25de595dc2d49900e73715f2b	addColumn tableName=supplier; dropColumn columnName=company_name, tableName=contact; dropColumn columnName=tax_number, tableName=contact		\N	4.27.0	\N	\N	4535944800
add-transactionClosed-column	jhipster	config/liquibase/changelog/20250112_addtransactionclosed.xml	2025-01-12 19:41:43.512435	45	EXECUTED	9:3693418e2be85260523560f00b88b603	addColumn tableName=product_return; addColumn tableName=purchase; addColumn tableName=sale; addColumn tableName=dispose; update tableName=product_return; update tableName=purchase; update tableName=sale; update tableName=dispose		\N	4.27.0	\N	\N	6707303454
rename-transactionClosed-column	jhipster	config/liquibase/changelog/20250112_renameransactionclosed.xml	2025-01-13 08:34:52.301569	46	EXECUTED	9:87efcd6bfe2b1c5ea3c06f5ba0d60ae4	renameColumn newColumnName=transaction_closed, oldColumnName=transactionClosed, tableName=product_return; renameColumn newColumnName=transaction_closed, oldColumnName=transactionClosed, tableName=purchase; renameColumn newColumnName=transaction_cl...		\N	4.27.0	\N	\N	6753692260
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: RPGCorner
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
\.


--
-- Data for Name: dispose; Type: TABLE DATA; Schema: public; Owner: RPGCorner
--

COPY public.dispose (id, dispose_date, note, disposed_by_user_id, transaction_closed) FROM stdin;
6	2024-12-09	felvesz akárcsak állj	2	f
7	2024-12-09	difi betonkád szöges	2	f
8	2024-12-08	ettől jaj hattyú	2	f
9	2024-12-09	rendbehoz napi pssz	2	f
10	2024-12-09	állj	2	f
1601	2024-12-01	56	1	f
1602	2024-12-01	wq	1	f
1603	2024-12-01	123	1	f
1901	2024-12-05	4	1	f
2001	2024-12-05	3	1	f
2701	2024-12-01	4	1	f
1	2024-12-09	lakkozás	3652	f
2	2024-12-09	mind ez idáig	3652	f
3	2024-12-09	akkortól keltez gardrób	3652	f
4	2024-12-09	haha apropos szerencsés	3652	f
5	2024-12-09	bizsereg ahá	3652	f
\.


--
-- Data for Name: disposed_stock; Type: TABLE DATA; Schema: public; Owner: RPGCorner
--

COPY public.disposed_stock (id, supplie, unit_price, disposed_ware_id, dispose_id) FROM stdin;
1	18715	27828	\N	\N
2	684	30052	\N	\N
3	12084	16307	\N	\N
4	26491	1623	\N	\N
5	3605	10512	\N	\N
6	10010	22132	\N	\N
7	17493	30042	\N	\N
8	8237	29083	\N	\N
9	14091	9271	\N	\N
10	24221	10143	\N	\N
1802	4	4	2	1901
1803	345	345	3	1901
2051	4	4	4	2001
2751	4	4	5	2701
3701	2	2	6	1
\.


--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: RPGCorner
--

COPY public.inventory (id, supplie, ware_id) FROM stdin;
2	13846	2
3	13534	3
4	26235	4
5	9378	5
6	27279	6
7	22331	7
8	12677	8
9	10894	9
10	15589	10
\.


--
-- Data for Name: jhi_authority; Type: TABLE DATA; Schema: public; Owner: RPGCorner
--

COPY public.jhi_authority (name) FROM stdin;
ROLE_ADMIN
ROLE_USER
SELLER
WAREHOUSE_MANAGER
\.


--
-- Data for Name: jhi_user; Type: TABLE DATA; Schema: public; Owner: RPGCorner
--

COPY public.jhi_user (id, login, password_hash, first_name, last_name, email, image_url, activated, lang_key, activation_key, reset_key, created_by, created_date, reset_date, last_modified_by, last_modified_date) FROM stdin;
1	admin	$2a$10$gSAhZrxMllrbgj/kkK9UceBPpChGWJA7SYIb1Mqo.n5aNLq1/oRrC	Administrator	Administrator	admin@localhost		t	hu	\N	\N	system	\N	\N	system	\N
3651	elado	$2a$10$gSAhZrxMllrbgj/kkK9UceBPpChGWJA7SYIb1Mqo.n5aNLq1/oRrC	Eladó 	Eladó 	elado@elado.hu	\N	t	hu	\N	xivLLh6RdUspsGbCnzU5	admin	2025-01-06 14:03:15.973617	2025-01-06 14:03:15.941777	admin	2025-01-06 14:05:30.437442
3652	raktarkezelo	$2a$10$gSAhZrxMllrbgj/kkK9UceBPpChGWJA7SYIb1Mqo.n5aNLq1/oRrC	raktarkezelo	raktarkezelo	raktarkezelo@raktarkezelo.hu	\N	t	hu	\N	DlnUamiAGaUrKbRdHETb	admin	2025-01-06 14:20:20.287195	2025-01-06 14:20:20.285962	admin	2025-01-06 14:20:20.287195
2	user	$2a$10$VEjxo0jq2YG9Rbk2HmX9S.k1uZBGYUHdUcid3g/vfiEl7lwWgOH/K	User	User	user@localhost		f	hu	\N	\N	system	\N	\N	admin	2025-01-06 14:53:31.315955
3801	admin2	$2a$10$WOiELUvJBdFXkhpeOchRkuLz/8HOOciC0/0NBrtU53ZTK9EEBKwPu	admin2	admin2	admin2@admin2.hu	\N	t	hu	\N	nMkoVuVMFGbzTQnFNX5a	admin	2025-01-07 16:52:50.010165	2025-01-07 16:52:49.977842	admin	2025-01-07 16:52:50.010165
\.


--
-- Data for Name: jhi_user_authority; Type: TABLE DATA; Schema: public; Owner: RPGCorner
--

COPY public.jhi_user_authority (user_id, authority_name) FROM stdin;
1	ROLE_ADMIN
1	ROLE_USER
2	ROLE_USER
3651	SELLER
3652	WAREHOUSE_MANAGER
3801	ROLE_ADMIN
\.


--
-- Data for Name: product_return; Type: TABLE DATA; Schema: public; Owner: RPGCorner
--

COPY public.product_return (id, return_date, note, sale_id, returned_by_user_id, returned_by_customer_id, transaction_closed) FROM stdin;
4	2024-12-09	from satöbbi above	\N	\N	\N	f
5	2024-12-09	gémüstökgomba brr	\N	\N	\N	f
6	2024-12-09	izzólámpa immár	\N	\N	\N	f
7	2024-12-09	tettes	\N	\N	\N	f
8	2024-12-09	a	\N	\N	\N	f
9	2024-12-09	ojjé	\N	\N	\N	f
10	2024-12-09	észrevétel állj	\N	\N	\N	f
2401	\N	\N	\N	\N	\N	f
2451	2024-12-06	23	2	1	10	f
2452	2024-12-07	12	2	1	1052	f
2453	\N	\N	\N	\N	\N	f
2454	2024-12-07	123	5	1	1053	f
2455	2024-11-30	12	3	1	1053	f
2456	2024-12-06	123	2	1	1053	f
3551	2024-12-01	12	4	1	3352	f
3	2024-12-09	megjegyzés3	2	3651	3	f
1	2024-12-09	megjegyzés1	3	3651	1	f
2	2024-12-09	megjegyzés2	4	3651	2	f
\.


--
-- Data for Name: purchase; Type: TABLE DATA; Schema: public; Owner: RPGCorner
--

COPY public.purchase (id, purchase_date, purchased_by_user_id, purchased_from_supplier_id, transaction_closed) FROM stdin;
3451	2024-12-28	3652	3001	f
2605	2024-12-01	3652	1	f
2601	2024-12-01	3652	1	f
5	2024-12-09	3652	5	f
2301	2024-12-01	3652	1151	f
2603	2024-12-18	3652	1	f
7	2024-12-09	3652	7	f
9	2024-12-09	3652	9	f
8	2024-12-08	3652	8	f
10	2024-12-09	3652	10	f
3452	2024-12-01	3652	2951	f
2604	2024-12-01	3652	1	f
2302	2024-12-01	3652	1151	f
4	2024-12-09	3652	4	f
6	2024-12-09	3652	6	f
2602	2024-12-01	3652	1	f
3	2024-12-09	3652	3	f
1	2024-12-09	3652	2951	f
2	2024-12-08	3652	2	f
\.


--
-- Data for Name: purchased_stock; Type: TABLE DATA; Schema: public; Owner: RPGCorner
--

COPY public.purchased_stock (id, supplie, unit_price, purchased_ware_id, purchase_id) FROM stdin;
1	25326	8304	\N	\N
2	14001	18203	\N	\N
3	13545	9966	\N	\N
4	9330	30860	\N	\N
5	23507	31556	\N	\N
6	6419	13954	\N	\N
7	10676	19549	\N	\N
8	5404	23638	\N	\N
9	8013	7665	\N	\N
10	8978	18939	\N	\N
2651	7	7	2	2603
3401	45	45	3	1
3501	1	1	5	3452
6001	1	1	3854	1
\.


--
-- Data for Name: returned_stock; Type: TABLE DATA; Schema: public; Owner: RPGCorner
--

COPY public.returned_stock (id, supplie, unit_price, returned_ware_id, product_return_id) FROM stdin;
1	12561	11575	\N	\N
2	26983	2386	\N	\N
3	27988	6269	\N	\N
4	13948	8141	\N	\N
5	31403	16506	\N	\N
6	21466	8383	\N	\N
7	16315	11730	\N	\N
8	21085	8268	\N	\N
9	29574	6161	\N	\N
10	154	3010	\N	\N
1351	500	1	2	3
2501	1	1	3	2456
3752	500	500	4	1
\.


--
-- Data for Name: sale; Type: TABLE DATA; Schema: public; Owner: RPGCorner
--

COPY public.sale (id, sold_date, sold_by_user_id, sold_for_customer_id, transaction_closed) FROM stdin;
2	2024-12-09	2	2	f
3	2024-12-09	2	3	f
4	2024-12-09	2	4	f
5	2024-12-09	2	5	f
6	2024-12-09	2	6	f
7	2024-12-09	1	7	f
8	2024-12-09	2	8	f
9	2024-12-09	2	9	f
10	2024-12-09	2	10	f
1451	\N	1	1	f
1501	2024-12-01	1	1	f
1502	2024-12-01	1	1	f
1503	2024-12-01	1	1	f
1504	2024-12-01	1	1	f
1651	2024-12-01	1	1	f
2101	2024-12-01	1	1	f
2102	2024-12-01	1	1	f
2201	2024-12-01	1	1	f
2251	2024-12-18	2	1053	f
2551	2024-12-01	1	1	f
2552	2024-12-01	1	1	f
2553	2024-12-07	1	1	f
1	2024-12-09	3651	1052	f
\.


--
-- Data for Name: sold_stock; Type: TABLE DATA; Schema: public; Owner: RPGCorner
--

COPY public.sold_stock (id, supplie, unit_price, returned_supplie, sold_ware_id, sale_id) FROM stdin;
1956	1	1	1	2	\N
2152	1	1	1	3	1
2156	5	5	5	4	1
2157	1	1	1	5	2201
2801	5	5	5	6	2553
\.


--
-- Data for Name: supplier; Type: TABLE DATA; Schema: public; Owner: RPGCorner
--

COPY public.supplier (id, company_name, tax_number) FROM stdin;
1151	\N	\N
2851	\N	\N
2901	\N	\N
2902	\N	\N
2903	\N	\N
2952	12312	3213
2953	434	343
3001	123r	123
2951	gfgfddd	fgf
3151	123	123
2	Cég 1	Cég 1
3	Cég 3	Cég 3
4	Cég 4	Cég 4
5	Cég 5	Cég 5
6	Cég 6	Cég 6
7	Cég 7	Cég 7
8	Cég 9	Cég 9
9	cég 10	cég 10
10	cég 11	cég 11
1101	Ceg 12	Ceg 12
5651	1	1
5652	1	1
5653	5	5
5701	5	5
5751	5	5
5752	5	5
5801	5	5
5851	5e	5
5852	2	2
5853	5	5
5854	5	5
5901	5	5
5951	5	5
1	Cég 10	Cég 10
5952	Cég 10	123123123
5953	Cég 10	12312312321
\.


--
-- Data for Name: ware; Type: TABLE DATA; Schema: public; Owner: RPGCorner
--

COPY public.ware (id, active, created, name, description, product_code, main_category_id, sub_category_id) FROM stdin;
9	f	2024-12-09	adóhátralék	haha tehát keresztülhajt	napjainkig over	9	\N
10	f	2024-12-09	minus hálóz	fontoskodó úgyhogy á	bizony	10	\N
3853	f	2025-01-01	Test 3	Test	Test	4	4
3851	f	2025-01-07	Test 1	Test	Test	6	6
3852	f	2025-01-01	Test 2	Test	Test	4	4
3854	f	2025-01-01	Test 4	Test	Test	4	4
3901	f	2025-01-25	2	2	2	3	3
3951	f	2025-01-01	Test1	Test1	Test1	4	5
7	f	2024-12-09	félre	Leírás7	1111111111	7	\N
6	t	2024-12-09	Név6	Leirás6	333333333	6	\N
5	f	2024-12-09	Név5	Leirás5	555555555	5	\N
4	f	2024-12-09	Név3	Leirás3	666666666	4	\N
8	f	2024-12-09	over mindenesetre apróbirtok	Leírás8	999999999999	8	\N
1	f	2024-12-09	Név1	Leírás1	1111111111111	1	9
2	f	2024-12-09	Név2	Leirás1	hhhhhhh	2	9
3	f	2024-12-09	Név3	Leirás3	777777777	3	\N
\.


--
-- Name: sequence_generator; Type: SEQUENCE SET; Schema: public; Owner: RPGCorner
--

SELECT pg_catalog.setval('public.sequence_generator', 6050, true);


--
-- Name: category category_pkey; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_pkey PRIMARY KEY (id);


--
-- Name: contact contact_pkey; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT contact_pkey PRIMARY KEY (id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: dispose dispose_pkey; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.dispose
    ADD CONSTRAINT dispose_pkey PRIMARY KEY (id);


--
-- Name: disposed_stock disposed_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.disposed_stock
    ADD CONSTRAINT disposed_stock_pkey PRIMARY KEY (id);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (id);


--
-- Name: jhi_authority jhi_authority_pkey; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.jhi_authority
    ADD CONSTRAINT jhi_authority_pkey PRIMARY KEY (name);


--
-- Name: jhi_user_authority jhi_user_authority_pkey; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.jhi_user_authority
    ADD CONSTRAINT jhi_user_authority_pkey PRIMARY KEY (user_id, authority_name);


--
-- Name: jhi_user jhi_user_pkey; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.jhi_user
    ADD CONSTRAINT jhi_user_pkey PRIMARY KEY (id);


--
-- Name: product_return product_return_pkey; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.product_return
    ADD CONSTRAINT product_return_pkey PRIMARY KEY (id);


--
-- Name: purchase purchase_pkey; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.purchase
    ADD CONSTRAINT purchase_pkey PRIMARY KEY (id);


--
-- Name: purchased_stock purchased_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.purchased_stock
    ADD CONSTRAINT purchased_stock_pkey PRIMARY KEY (id);


--
-- Name: returned_stock returned_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.returned_stock
    ADD CONSTRAINT returned_stock_pkey PRIMARY KEY (id);


--
-- Name: sale sale_pkey; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.sale
    ADD CONSTRAINT sale_pkey PRIMARY KEY (id);


--
-- Name: sold_stock sold_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.sold_stock
    ADD CONSTRAINT sold_stock_pkey PRIMARY KEY (id);


--
-- Name: supplier supplier_pkey; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.supplier
    ADD CONSTRAINT supplier_pkey PRIMARY KEY (id);


--
-- Name: customer ux_customer__contact_id; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT ux_customer__contact_id UNIQUE (contact_id);


--
-- Name: disposed_stock ux_disposed_stock__disposed_ware_id; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.disposed_stock
    ADD CONSTRAINT ux_disposed_stock__disposed_ware_id UNIQUE (disposed_ware_id);


--
-- Name: inventory ux_inventory__ware_id; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT ux_inventory__ware_id UNIQUE (ware_id);


--
-- Name: purchased_stock ux_purchased_stock__purchased_ware_id; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.purchased_stock
    ADD CONSTRAINT ux_purchased_stock__purchased_ware_id UNIQUE (purchased_ware_id);


--
-- Name: returned_stock ux_returned_stock__returned_ware_id; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.returned_stock
    ADD CONSTRAINT ux_returned_stock__returned_ware_id UNIQUE (returned_ware_id);


--
-- Name: sold_stock ux_sold_stock__sold_ware_id; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.sold_stock
    ADD CONSTRAINT ux_sold_stock__sold_ware_id UNIQUE (sold_ware_id);


--
-- Name: jhi_user ux_user_email; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.jhi_user
    ADD CONSTRAINT ux_user_email UNIQUE (email);


--
-- Name: jhi_user ux_user_login; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.jhi_user
    ADD CONSTRAINT ux_user_login UNIQUE (login);


--
-- Name: ware ware_pkey; Type: CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.ware
    ADD CONSTRAINT ware_pkey PRIMARY KEY (id);


--
-- Name: jhi_user_authority fk_authority_name; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.jhi_user_authority
    ADD CONSTRAINT fk_authority_name FOREIGN KEY (authority_name) REFERENCES public.jhi_authority(name);


--
-- Name: category fk_category__main_category_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT fk_category__main_category_id FOREIGN KEY (main_category_id) REFERENCES public.category(id);


--
-- Name: contact fk_contact__supplier_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT fk_contact__supplier_id FOREIGN KEY (supplier_id) REFERENCES public.supplier(id);


--
-- Name: customer fk_customer__contact_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT fk_customer__contact_id FOREIGN KEY (contact_id) REFERENCES public.contact(id);


--
-- Name: dispose fk_dispose__disposed_by_user_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.dispose
    ADD CONSTRAINT fk_dispose__disposed_by_user_id FOREIGN KEY (disposed_by_user_id) REFERENCES public.jhi_user(id);


--
-- Name: disposed_stock fk_disposed_stock__dispose_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.disposed_stock
    ADD CONSTRAINT fk_disposed_stock__dispose_id FOREIGN KEY (dispose_id) REFERENCES public.dispose(id);


--
-- Name: disposed_stock fk_disposed_stock__disposed_ware_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.disposed_stock
    ADD CONSTRAINT fk_disposed_stock__disposed_ware_id FOREIGN KEY (disposed_ware_id) REFERENCES public.ware(id);


--
-- Name: inventory fk_inventory__ware_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT fk_inventory__ware_id FOREIGN KEY (ware_id) REFERENCES public.ware(id);


--
-- Name: product_return fk_product_return__returned_by_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.product_return
    ADD CONSTRAINT fk_product_return__returned_by_customer_id FOREIGN KEY (returned_by_customer_id) REFERENCES public.customer(id);


--
-- Name: product_return fk_product_return__returned_by_user_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.product_return
    ADD CONSTRAINT fk_product_return__returned_by_user_id FOREIGN KEY (returned_by_user_id) REFERENCES public.jhi_user(id);


--
-- Name: product_return fk_product_return__sale_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.product_return
    ADD CONSTRAINT fk_product_return__sale_id FOREIGN KEY (sale_id) REFERENCES public.sale(id);


--
-- Name: purchase fk_purchase__purchased_by_user_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.purchase
    ADD CONSTRAINT fk_purchase__purchased_by_user_id FOREIGN KEY (purchased_by_user_id) REFERENCES public.jhi_user(id);


--
-- Name: purchase fk_purchase__purchased_from_supplier_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.purchase
    ADD CONSTRAINT fk_purchase__purchased_from_supplier_id FOREIGN KEY (purchased_from_supplier_id) REFERENCES public.supplier(id);


--
-- Name: purchased_stock fk_purchased_stock__purchase_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.purchased_stock
    ADD CONSTRAINT fk_purchased_stock__purchase_id FOREIGN KEY (purchase_id) REFERENCES public.purchase(id);


--
-- Name: purchased_stock fk_purchased_stock__purchased_ware_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.purchased_stock
    ADD CONSTRAINT fk_purchased_stock__purchased_ware_id FOREIGN KEY (purchased_ware_id) REFERENCES public.ware(id);


--
-- Name: returned_stock fk_returned_stock__product_return_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.returned_stock
    ADD CONSTRAINT fk_returned_stock__product_return_id FOREIGN KEY (product_return_id) REFERENCES public.product_return(id);


--
-- Name: returned_stock fk_returned_stock__returned_ware_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.returned_stock
    ADD CONSTRAINT fk_returned_stock__returned_ware_id FOREIGN KEY (returned_ware_id) REFERENCES public.ware(id);


--
-- Name: sale fk_sale__sold_by_user_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.sale
    ADD CONSTRAINT fk_sale__sold_by_user_id FOREIGN KEY (sold_by_user_id) REFERENCES public.jhi_user(id);


--
-- Name: sale fk_sale__sold_for_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.sale
    ADD CONSTRAINT fk_sale__sold_for_customer_id FOREIGN KEY (sold_for_customer_id) REFERENCES public.customer(id);


--
-- Name: sold_stock fk_sold_stock__sale_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.sold_stock
    ADD CONSTRAINT fk_sold_stock__sale_id FOREIGN KEY (sale_id) REFERENCES public.sale(id);


--
-- Name: sold_stock fk_sold_stock__sold_ware_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.sold_stock
    ADD CONSTRAINT fk_sold_stock__sold_ware_id FOREIGN KEY (sold_ware_id) REFERENCES public.ware(id);


--
-- Name: jhi_user_authority fk_user_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.jhi_user_authority
    ADD CONSTRAINT fk_user_id FOREIGN KEY (user_id) REFERENCES public.jhi_user(id);


--
-- Name: ware fk_ware__main_category_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.ware
    ADD CONSTRAINT fk_ware__main_category_id FOREIGN KEY (main_category_id) REFERENCES public.category(id);


--
-- Name: ware fk_ware__sub_category_id; Type: FK CONSTRAINT; Schema: public; Owner: RPGCorner
--

ALTER TABLE ONLY public.ware
    ADD CONSTRAINT fk_ware__sub_category_id FOREIGN KEY (sub_category_id) REFERENCES public.category(id);


--
-- PostgreSQL database dump complete
--

